function checkForm(){
	var username=document.getElementById("username");
	var password=document.getElementById("password");
	if(username.value == ""){
		username.setCustomValidity("The Username cannot be null !");
	}
	if(password.value == ""){
		password.setCustomValidity("The PassWord cannot be null !");
	}	
}
function register(){
	window.location.href="RegisterPage.jsp";
}
function submitPage(){
	window.location.href="HomePage.jsp";
}