function check(){
	var tittle = document.getElementById("tittle");
	var gender = document.getElementById("gender");
	var plot = document.getElementById("plot");
	var duration = document.getElementById("duration");
	if(tittle.value == ""){
		tittle.setCustomValidity("Enter the tittle please.");
	}
	if(gender.value == ""){
		gender.setCustomValidity("Enter the gender please");
	}
	if(plot.value == ""){
		plot.setCustomValidity("Enter the plot summary please");
	}
	if(duration.value ==""){
		duration.setCustomValidity("Enter the duration please");
	}
}
function submitPage(){
	window.location.href="MainPage.jsp";
}
function check1(){
	var tittle = document.getElementById("tittle");
	var gender = document.getElementById("gender");
	var plot = document.getElementById("plot");
	var duration = document.getElementById("duration");
	var mpaa = document.getElementById("mpaa");
	var premiered = document.getElementById("premiered");
	var studio = document.getElementById("studio");
	var name = document.getElementById("name");
	var role = document.getElementById("role");
	var name1 = document.getElementById("name1");
	var role1 = document.getElementById("role1");
	if(tittle.value == ""){
		tittle.setCustomValidity("Enter the tittle please.");
	}
	if(gender.value == ""){
		gender.setCustomValidity("Enter the gender please");
	}
	if(plot.value == ""){
		plot.setCustomValidity("Enter the plot summary please");
	}
	if(duration.value ==""){
		duration.setCustomValidity("Enter the duration please");
	}
	if(mpaa.value == ""){
		mpaa.setCustomValidity("Enter the mpaa please.");
	}
	if(premiered.value == ""){
		premiered.setCustomValidity("Enter the premiered please.");
	}
	if(studio.value == ""){
		studio.setCustomValidity("Enter the studio please.");
	}
	if(name.value == ""){
		name.setCustomValidity("Enter the name please.");
	}
	if(role.value == ""){
		role.setCustomValidity("Enter the role please.");
	}
	if(name1.value == ""){
		name1.setCustomValidity("Enter the name please.");
	}
	if(role1.value == ""){
		role1.setCustomValidity("Enter the role please.");
	}
}

function check2(){
	var tittle = document.getElementById("tittle");
	var gender = document.getElementById("gender");
	var plot = document.getElementById("plot");
	var duration = document.getElementById("duration");
	if(tittle.value == ""){
		tittle.setCustomValidity("Enter the tittle please.");
	}
	if(gender.value == ""){
		gender.setCustomValidity("Enter the gender please");
	}
	if(plot.value == ""){
		plot.setCustomValidity("Enter the plot summary please");
	}
	if(duration.value ==""){
		duration.setCustomValidity("Enter the duration please");
	}
}

function check3(){
	var tittle = document.getElementById("tittle");
	var gender = document.getElementById("gender");
	var nation = document.getElementById("plot");
	if(tittle.value == ""){
		tittle.setCustomValidity("Enter the tittle please.");
	}
	if(gender.value == ""){
		gender.setCustomValidity("Enter the gender please");
	}
	if(nation.value == ""){
		plot.setCustomValidity("Enter the nation please");
	}
}

function check4(){
	var tittle = document.getElementById("tittle");
	var gender = document.getElementById("gender");
	var plot = document.getElementById("plot");
	var duration = document.getElementById("duration");
	if(tittle.value == ""){
		tittle.setCustomValidity("Enter the tittle please.");
	}
	if(gender.value == ""){
		gender.setCustomValidity("Enter the gender please");
	}
	if(plot.value == ""){
		plot.setCustomValidity("Enter the plot summary please");
	}
	if(duration.value ==""){
		duration.setCustomValidity("Enter the duration please");
	}
}