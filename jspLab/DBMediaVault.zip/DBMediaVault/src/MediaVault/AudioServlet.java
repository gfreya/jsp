package MediaVault;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AudioServlet
 */
@WebServlet("/AudioServlet")
public class AudioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AudioServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println("CONNECT");
		int decision=0;
		if(request.getParameter("au1")!=null){
			decision=1;
		}else if(request.getParameter("au2")!=null){
			//System.out.println("p2");
			decision=2;
		}else if(request.getParameter("au3")!=null){
			decision = 3;
		}else{
			decision = 4;
		}
		//System.out.println(decision);
		File file=null;
		switch (decision) {
		case 1:
			file=new File("E:\\XAMPP\\htdocs\\DBMediaVault\\"+"WebContent\\media\\1.mp3");
			break;
		case 2:
			file=new File("E:\\XAMPP\\htdocs\\DBMediaVault\\"+"WebContent\\media\\2.mp3");
			break;
		case 3:
			file=new File("E:\\XAMPP\\htdocs\\DBMediaVault\\"+"WebContent\\media\\3.mp3");
			break;
		case 4:
			file=new File("E:\\XAMPP\\htdocs\\DBMediaVault\\"+"WebContent\\media\\4.mp3");
			break;
		default:	
			break;
		}  
       	 if(file.exists()){  
                FileInputStream  fis = new FileInputStream(file);  
                String filename=URLEncoder.encode(file.getName(),"utf-8"); 
                byte[] b = new byte[fis.available()];  
                fis.read(b);  
                response.setCharacterEncoding("utf-8");  
                response.setHeader("Content-Disposition","attachment; filename="+filename+"");  
                ServletOutputStream  out =response.getOutputStream();  
                out.write(b);  
                out.flush();  
                out.close();  
                fis.close();
            }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
