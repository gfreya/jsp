package MediaVault;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PictureServlet
 */
@WebServlet("/PictureServlet")
public class PictureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PictureServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int decision=0;
		if(request.getParameter("p1")!=null){
			decision=1;
		}else if(request.getParameter("p2")!=null){
			//System.out.println("p2");
			decision=2;
		}else if(request.getParameter("p3")!=null){
			decision = 3;
		}else{
			decision = 4;
		}
		//System.out.println(decision);
		File file=null;
		switch (decision) {
		case 1:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\10.jpg");
			break;
		case 2:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\11.jpg");
			break;
		case 3:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\12.jpg");
			break;
		case 4:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\13.jpg");
			break;
		default:	
			break;
		}  
       	 if(file.exists()){  
                FileInputStream  fis = new FileInputStream(file);  
                String filename=URLEncoder.encode(file.getName(),"utf-8"); 
                byte[] b = new byte[fis.available()];  
                fis.read(b);  
                response.setCharacterEncoding("utf-8");  
                response.setHeader("Content-Disposition","attachment; filename="+filename+"");  
                ServletOutputStream  out =response.getOutputStream();  
                out.write(b);  
                out.flush();  
                out.close();  
                fis.close();
            }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
