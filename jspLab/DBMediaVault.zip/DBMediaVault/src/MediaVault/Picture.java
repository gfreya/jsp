package MediaVault;

public class Picture extends Media{
	private String pid;
	public String getPId() {
		return pid;
	}

	public void setPId(String pid) {
		this.pid = pid;
	}

	private String artist;

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}
	
}
