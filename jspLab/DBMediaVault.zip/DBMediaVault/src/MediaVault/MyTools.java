package MediaVault;

import java.io.File;

public class MyTools {
	public static int strToint(String str){
		if(str==null||str.equals("")){
			str="0";
		}
		int i=0;
		try {
			i=Integer.parseInt(str);
		} catch (NumberFormatException e) {
			// TODO: handle exception
			i=0;
			e.printStackTrace();
		}
		return i;
	}
	
	public static float strToFloat(String str){
		if(str==null||str.equals("")){
			str="0";
		}
		float i=0;
		try {
			i=Float.parseFloat(str);
		} catch (NumberFormatException e) {
			// TODO: handle exception
			i=0;
			e.printStackTrace();
		}
		return i;
	}
	
	public static File strToFile(String str){
		File file;
		if(str==null||str.equals("")){
		file=null;
		}else{
		file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media"+str);}
		return file;
	}
}
