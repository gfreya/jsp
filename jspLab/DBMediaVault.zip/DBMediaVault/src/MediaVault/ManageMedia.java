package MediaVault;

import java.util.ArrayList;

public class ManageMedia {
	private static ArrayList<Movie> movies = new ArrayList<>();
	private static ArrayList<TVShow> tvShows = new ArrayList<>();
	private static ArrayList<Album> albums = new ArrayList<>();
	private static ArrayList<Audio> audios = new ArrayList<>();
	
	public ArrayList<Movie> getMovies() {
		return movies;
	}
	public ArrayList<TVShow> getTVShows() {
		return tvShows;
	}
	public ArrayList<Album> getAlbum() {
		return albums;
	}
	public ArrayList<Audio> getAudios() {
		return audios;
	}
	public void addMovie(Movie movie){
		if(movie!=null){
			Movie tempMovie = new Movie();
			int m = movies.size()+1;
			String mid = "mm"+m;
			tempMovie.setMID(mid);
			tempMovie.setTitle(movie.getTitle());
			tempMovie.setGenre(movie.getGenre());
			tempMovie.setThumb(movie.getThumb());
			tempMovie.setRating(movie.getRating());
			tempMovie.setDuration(movie.getDuration());
			movies.add(tempMovie);
		}
	}
	public void addTVShow(TVShow tvShow){
		if(tvShow!=null){
			TVShow tempTVShow = new TVShow();
			int c = tvShows.size()+1;
			String tid = "t"+c;
			tempTVShow.setTID(tid);
			tempTVShow.setTitle(tvShow.getTitle());
			tempTVShow.setGenre(tvShow.getGenre());
			tempTVShow.setThumb(tvShow.getThumb());
			tempTVShow.setRating(tvShow.getRating());
			tempTVShow.setPlot(tvShow.getPlot());
			tempTVShow.setRuntime(tvShow.getRuntime());
			tempTVShow.setMpaa(tvShow.getMpaa());
			tempTVShow.setPremiered(tvShow.getPremiered());
			tempTVShow.setStudio(tvShow.getStudio());
			tempTVShow.setActor(tvShow.getActor());
			tempTVShow.setActorThumb(tvShow.getActorThumb());
			tvShows.add(tvShow);
		}
	}
	public void addAlbum(Album album){
		if(album!=null){
			Album tempAlbum = new Album();
			int c = albums.size()+1;
			String aid = "a"+c;
			tempAlbum.setAID(aid);
			tempAlbum.setTitle(album.getTitle());
			tempAlbum.setGenre(album.getGenre());
			tempAlbum.setThumb(album.getThumb());
			tempAlbum.setReleasedate(album.getReleasedate());
			tempAlbum.setLabel(album.getLabel());
			albums.add(album);
		}
	}
	
	public void addAudio(Audio audio){
		if(audio!=null){
			Audio tempAudio = new Audio();
			int num = audios.size()+1;
			tempAudio.setAuid("au"+num);
			tempAudio.setTittle(audio.getTittle());
			tempAudio.setGenre(audio.getGenre());
			tempAudio.setThumb(audio.getThumb());
			tempAudio.setDuration(audio.getDuration());
			audios.add(tempAudio);
		}
	}
}
