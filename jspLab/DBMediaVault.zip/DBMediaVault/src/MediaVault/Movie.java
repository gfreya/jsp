package MediaVault;

public class Movie extends Media {
	private String mid;
	private float rating;
	private int duration;
	public void setMID(String mid){
		this.mid=mid;
	}
	public String getMID(){
		return mid;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
