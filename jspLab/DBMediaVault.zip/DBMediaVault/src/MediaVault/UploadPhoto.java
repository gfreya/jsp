package MediaVault;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class UploadPhoto
 */
@WebServlet("/UploadPhoto")
public class UploadPhoto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadPhoto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ManageMedia manageMedia = new ManageMedia();		
		String tempDirectory = "F:/zxh/";    
		DBConn dbConn = new DBConn();
		PreparedStatement preparedStatement = null;
		String sql = "insert into album(aid,tittle,genre,thumb,label) values(?,?,?,?,?)";
        try {  
            int sizeThreshold = 1024 * 64;    
            File repositoryFile = new File(tempDirectory);  
            FileItemFactory factory = new DiskFileItemFactory(sizeThreshold, repositoryFile);  
            ServletFileUpload upload = new ServletFileUpload(factory);  
            upload.setHeaderEncoding("utf-8");   
            upload.setSizeMax(50 * 1024 * 1024);   
            List<FileItem> items = upload.parseRequest(request);  
            Iterator<FileItem> iter = items.iterator();     
        	preparedStatement=(PreparedStatement) DBConn.getPreparedStatement(dbConn.getConnection(), sql);
            int c = manageMedia.getAlbum().size()+1;
            System.out.println(c);
        	preparedStatement.setString(1, "a"+c);
        	while (iter.hasNext()) {  
                FileItem item = (FileItem) iter.next(); 
                if(item.isFormField()){
                	if(item.getFieldName().equals("tittle")){
                		preparedStatement.setString(2, item.getString());
                	}
                	if(item.getFieldName().equals("gender")){
                		preparedStatement.setString(3, item.getString());
                	}
                	if(item.getFieldName().equals("nation")){
                		preparedStatement.setString(5, item.getString());
                	}
                	
                }
                if(!item.isFormField()){ 
                	processUploadFile(item);
                	String filePath = item.getName();         
        	        int index = filePath.lastIndexOf("\\");  
        	        String filename = filePath.substring(index + 1, filePath.length());
                	if(item.getFieldName().equals("thumbnail")){
                		System.out.println(item.getName());          		
                		String thumb = "media/"+filename;
                		preparedStatement.setString(4, thumb);
                	}
                	
                }                
                
             
            }  
        	preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (Exception e) {  
            e.printStackTrace();  
        }      
	}
	
	private void processUploadFile(FileItem item) throws Exception  
    {  
        String filePath = item.getName();         
        int index = filePath.lastIndexOf("\\");  
        String filename = filePath.substring(index + 1, filePath.length());  
        long fileSize = item.getSize();  
        if("".equals(filename) && fileSize == 0)  
        {             
            System.out.println("Empty...");  
            return ;  
        }  
        File uploadFile = new File("E:/XAMPP/htdocs/DBMediaVault/WebContent/media/"+filename);  
        item.write(uploadFile);  
        //return filename;
    }   

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
