package MediaVault;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static int count=1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub	
		String username = request.getParameter("username");
		String phone_num = request.getParameter("phone_num");
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		String password = request.getParameter("password");
		String password1 = request.getParameter("password1");
		if(password.equals(password1)){
			DBConn dbConn = new DBConn();
			PreparedStatement preparedStatement = null;
			String sql = "insert into userinfo(id,uname,phone_num,email,gender,user_password) values(?,?,?,?,?,?)";
			try {
				String id="e"+count;
				count++;
				preparedStatement=(PreparedStatement) DBConn.getPreparedStatement(dbConn.getConnection(), sql);
				preparedStatement.setString(1, id);
				preparedStatement.setString(2, username);
				preparedStatement.setString(3, phone_num);
				preparedStatement.setString(4, email);
				preparedStatement.setString(5, gender);
				preparedStatement.setString(6, password);
				preparedStatement.executeUpdate();
				//DBConn.executeUpdate(dbConn.getConnection(), sql);
//				ResultSet resultSet = preparedStatement.executeQuery();
//				while (resultSet.next()) {
//					System.out.println(resultSet.getString("id"));
//					
//				}
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("/DBMediaVault/Login.jsp");
         }  
         
		else{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.write("<html><head><tittle>Error</tittle></head>");
			out.write("<body> Error </body></html>");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
