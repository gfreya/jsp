package MediaVault;

import java.util.ArrayList;

public class Album extends Media {
	private String aid;
	private String review;
	private String releasedate;
	private String label;
	private ArrayList<Picture> pictures;
	
	public void setAID(String aid){
		this.aid=aid;
	}
	public String getAID(){
		return aid;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public String getReleasedate() {
		return releasedate;
	}
	public void setReleasedate(String releasedate) {
		this.releasedate = releasedate;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public ArrayList<Picture> getPictures() {
		return pictures;
	}
	public void setPictures(ArrayList<Picture> pictures) {
		this.pictures = pictures;
	}
	public void addPicture(Picture picture){
		getPictures().add(picture);
	}
	public void removePictur(Picture picture){
		getPictures().remove(picture.getPId());
	}
}
