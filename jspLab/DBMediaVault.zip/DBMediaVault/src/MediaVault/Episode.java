
package MediaVault;

public class Episode extends Media {
	private int eid;
	private float rating;
	private int season;
	private int episode_num;
	private String episode_plot;
	private int duration;
	public void setEID(int eid){
		this.eid = eid;
	}
	public int getEID(){
		return this.eid;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public int getSeason() {
		return season;
	}
	public void setSeason(int season) {
		this.season = season;
	}
	public int getEpisode_num() {
		return episode_num;
	}
	public void setEpisode_num(int episode_num) {
		this.episode_num = episode_num;
	}
	public String getEpisode_plot() {
		return episode_plot;
	}
	public void setEpisode_plot(String episode_plot) {
		this.episode_plot = episode_plot;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
