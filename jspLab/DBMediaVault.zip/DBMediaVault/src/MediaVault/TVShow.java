package MediaVault;

import java.io.File;
import java.util.ArrayList;

public class TVShow extends Media{
	private float rating;
	private String plot;
	private int runtime;
	private String mpaa;
	private String tid;
	private String premiered;
	private String studio;
	private String actor;
	private File actorThumb;
	private ArrayList<Episode> episodes;
	
	public ArrayList<Episode> getEpisodes() {
		return episodes;
	}
	public void setEpisodes(ArrayList<Episode> episodes) {
		this.episodes = episodes;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public String getPlot() {
		return plot;
	}
	public void setPlot(String plot) {
		this.plot = plot;
	}
	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	public String getMpaa() {
		return mpaa;
	}
	public void setMpaa(String mpaa) {
		this.mpaa = mpaa;
	}
	public String getTID() {
		return tid;
	}
	public void setTID(String tid) {
		this.tid=tid;
	}
	public String getPremiered() {
		return premiered;
	}
	public void setPremiered(String premiered) {
		this.premiered = premiered;
	}
	public String getStudio() {
		return studio;
	}
	public void setStudio(String studio) {
		this.studio = studio;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public File getActorThumb() {
		return actorThumb;
	}
	public void setActorThumb(File actorThumb) {
		this.actorThumb = actorThumb;
	}
	
	public void addEpisode(Episode episode){
		getEpisodes().add(episode);
	}
	
	public void removeEpisode(Episode episode){
		getEpisodes().remove(episode.getEID());
	}
}
