package MediaVault;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.filefilter.DelegateFileFilter;

/**
 * Servlet implementation class RemoveServlet
 */
@WebServlet("/RemoveServlet")
public class RemoveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String delete1= request.getParameter("delete1");
		if(delete1!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\1.1.flv");
			file.delete();
			File file2 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\2.flv");
			file2.delete();
		}
		String delete2 = request.getParameter("delete2");
		if(delete2!=null){
			File file3 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\2.1.flv");
			file3.delete();
			File file4 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\2.2.flv");
			file4.delete();
			File file5 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\3.flv");
			file5.delete();
		}
		String delete3 = request.getParameter("delete3");
		if(delete3!=null){
			File file6 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\3.1.flv");
			file6.delete();
			File file7 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\3.2.flv");
			file7.delete();
			File file8 = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\4.flv");
			file8.delete();
		}
		String delete4= request.getParameter("delete4");
		if(delete4!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\1.flv");
			file.delete();
		}
		String delete5= request.getParameter("delete5");
		if(delete5!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\5.flv");
			file.delete();
		}
		String delete6= request.getParameter("delete6");
		if(delete6!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\1.mp3");
			file.delete();
		}
		String delete7= request.getParameter("delete7");
		if(delete7!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\2.mp3");
			file.delete();
		}
		String delete8= request.getParameter("delete8");
		if(delete8!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\3.mp3");
			file.delete();
		}
		String delete9= request.getParameter("delete9");
		if(delete9!=null){
			File file = new File("E:\\XAMPP\\htdocs\\DBMediaVault\\WebContent\\media\\4.mp3");
			file.delete();
		}
		PrintWriter pWriter = response.getWriter();
		pWriter.write("Successfully Delete");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
