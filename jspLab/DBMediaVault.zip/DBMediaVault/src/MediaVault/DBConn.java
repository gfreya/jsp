package MediaVault;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBConn {
	private String driver="com.mysql.jdbc.Driver";
	//private String driver="org.gjt.mm.mysql.Driver";
	private final String url="jdbc:mysql://localhost:3306/mediavault?useUnicode=true&characterEncoding=utf-8";
	private String dbName;
	private String tableName;
	private String username="root";
	private String password="ZXHzxh777";
	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;
	
	//getters and setters
	public String getUrl() {
		return url;
	}
	public String getDbName() {
		return dbName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableName() {
		return tableName;
	}
	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	
   //get the ResultSet of the table	
	public ResultSet showTable(){
		try {
			 this.statement = getConnection().createStatement();
			 String query = "SELECT * FROM"+getTableName();
			 this.resultSet = statement.executeQuery(query);
			 getConnection().close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this.resultSet;
	}
	//get prepared statement
	public static PreparedStatement getPreparedStatement(Connection con,String sql)
	 
	 {
	  PreparedStatement psta=null;
	  try {
	   psta=con.prepareStatement(sql);
	  } catch (SQLException e) {
	   e.printStackTrace();
	  }
	  return psta;
	  
	 }
	//get the ResultSet based on the parameter sql 
	public static ResultSet getResultSet(Statement sta,String sql)
	 
	 {
	  ResultSet rs=null;
	  try {
	    rs=sta.executeQuery(sql);
	  } catch (SQLException e) {
	   e.printStackTrace();
	  }
	  return rs;
	 }
	
	//get the connection of the database
	public Connection getConnection(){
		try {
			 Class.forName(driver).newInstance();
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	//execute update
	public static void executeUpdate(Connection con,String sql)
	{
	 Statement sta=null;
	 try {
	  sta=con.createStatement();
	  sta.executeUpdate(sql);
	 } catch (SQLException e) {
	  e.printStackTrace();
	 }
	}
	
}
