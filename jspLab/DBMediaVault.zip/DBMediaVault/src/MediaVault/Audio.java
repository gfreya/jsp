package MediaVault;

import java.io.File;

public class Audio {
	private String auid;
	private String tittle;
	private String genre;
	private File thumb;
	private int duration;
	private File resource;
	public String getAuid() {
		return auid;
	}
	public void setAuid(String auid) {
		this.auid = auid;
	}
	public String getTittle() {
		return tittle;
	}
	public void setTittle(String tittle) {
		this.tittle = tittle;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public File getThumb() {
		return thumb;
	}
	public void setThumb(File thumb) {
		this.thumb = thumb;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public File getResource() {
		return resource;
	}
	public void setResource(File resource) {
		this.resource = resource;
	}
}
