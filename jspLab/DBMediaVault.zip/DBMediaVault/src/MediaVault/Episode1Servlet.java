package MediaVault;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Episode1Servlet
 */
@WebServlet("/Episode1Servlet")
public class Episode1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Episode1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int decision=0;
		if(request.getParameter("e1")!=null){
			decision=1;
		}else if(request.getParameter("e2")!=null){
			System.out.println("e2");
			decision=2;
		}else if(request.getParameter("e3")!=null){
			decision = 3;
		}else if(request.getParameter("e4")!=null){
			decision = 4;
		}else if(request.getParameter("e5")!=null){
			decision = 5;
		}else if(request.getParameter("e6")!=null){
			decision = 6;
		}else if(request.getParameter("e7")!=null){
			decision = 7;
		}else{
			decision = 8;
		}
		//System.out.println(decision);
		File file=null;
		switch (decision) {
		case 1:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\1.1.flv");
			break;
		case 2:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\2.flv");
			break;
		case 3:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\2.1.flv");
			break;
		case 4:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\2.2.flv");
			break;
		case 5:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\3.flv");
			break;
		case 6:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\3.1.flv");
			break;
		case 7:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\3.2.flv");
			break;
		case 8:
			file=new File("E:\\XAMPP\\htdocs\\MediaVault\\"+"WebContent\\media\\4.flv");
			break;
		default:	
			break;
		}  
       	 if(file.exists()){  
                FileInputStream  fis = new FileInputStream(file);  
                String filename=URLEncoder.encode(file.getName(),"utf-8"); 
                byte[] b = new byte[fis.available()];  
                fis.read(b);  
                response.setCharacterEncoding("utf-8");  
                response.setHeader("Content-Disposition","attachment; filename="+filename+"");  
                ServletOutputStream  out =response.getOutputStream();  
                out.write(b);  
                out.flush();  
                out.close();  
                fis.close();
            }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
